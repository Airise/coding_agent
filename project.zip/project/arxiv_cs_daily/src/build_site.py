import os
import json
import shutil
from datetime import datetime
from pathlib import Path

# Directory paths
PAPERS_DIR = "project/arxiv_cs_daily/papers"
STATIC_DIR = "project/arxiv_cs_daily/static"
TEMPLATES_DIR = "project/arxiv_cs_daily/templates"
OUTPUT_DIR = "project/arxiv_cs_daily/output"

# Ensure required directories exist
os.makedirs(PAPERS_DIR, exist_ok=True)
os.makedirs(STATIC_DIR, exist_ok=True)
os.makedirs(TEMPLATES_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)

# List of CS categories on arXiv
CS_CATEGORIES = {
    "cs.AI": "Artificial Intelligence",
    "cs.CL": "Computation and Language",
    "cs.CV": "Computer Vision and Pattern Recognition",
    "cs.CY": "Computers and Society",
    "cs.DB": "Databases",
    "cs.DC": "Distributed, Parallel, and Cluster Computing",
    "cs.ET": "Emerging Technologies",
    "cs.FL": "Formal Languages and Automata Theory",
    "cs.GL": "General Literature",
    "cs.GR": "Graphics",
    "cs.HC": "Human-Computer Interaction",
    "cs.IR": "Information Retrieval",
    "cs.IT": "Information Theory",
    "cs.LG": "Machine Learning",
    "cs.LO": "Logic in Computer Science",
    "cs.NE": "Neural and Evolutionary Computing",
    "cs.NI": "Networking and Internet Architecture",
    "cs.OH": "Other Computer Science",
    "cs.PF": "Performance",
    "cs.PL": "Programming Languages",
    "cs.RO": "Robotics",
    "cs.SC": "Symbolic Computation",
    "cs.SD": "Sound",
    "cs.SE": "Software Engineering",
    "cs.SI": "Social and Information Networks",
    "cs.SY": "Systems and Control"
}

# Sample paper data (in practice, this would come from arXiv API)
SAMPLE_PAPERS = [
    {
        "id": "2403.12345",
        "title": "A Novel Approach to Self-Supervised Learning in Vision Transformers",
        "authors": [
            {"name": "Alice Johnson", "affiliation": "Stanford University"},
            {"name": "Bob Lee", "affiliation": "Google Research"}
        ],
        "abstract": "We present a new method for self-supervised learning in vision transformers...",
        "submitted": "2024-03-20T14:23:01Z",
        "updated": "2024-03-20T14:23:01Z",
        "categories": ["cs.CV", "cs.LG"],
        "doi": None,
        "primary_category": "cs.CV"
    },
    {
        "id": "2403.12346",
        "title": "Efficient Algorithms for Large-Scale Graph Processing",
        "authors": [
            {"name": "Charlie Davis", "affiliation": "MIT"},
            {"name": "Diana Chen", "affiliation": "Facebook AI"}
        ],
        "abstract": "This paper introduces efficient algorithms for processing large-scale graphs...",
        "submitted": "2024-03-20T10:15:33Z",
        "updated": "2024-03-20T10:15:33Z",
        "categories": ["cs.DC", "cs.DS"],
        "doi": "10.1145/1234567890",
        "primary_category": "cs.DC"
    },
    {
        "id": "2403.12347",
        "title": "Ethical Considerations in AI-Powered Healthcare Systems",
        "authors": [
            {"name": "Eva Martinez", "affiliation": "Harvard Medical School"},
            {"name": "Frank Wilson", "affiliation": "Johns Hopkins University"}
        ],
        "abstract": "We analyze ethical challenges in deploying AI systems in healthcare settings...",
        "submitted": "2024-03-19T16:45:22Z",
        "updated": "2024-03-19T16:45:22Z",
        "categories": ["cs.CY", "cs.AI"],
        "doi": None,
        "primary_category": "cs.CY"
    }
]

def generate_bibtex(paper):
    """Generate BibTeX citation for a paper."""
    key = f"{paper['authors'][0]['name'].split()[-1].lower()}{paper['submitted'][:4]}{paper['id'].replace('.', '')}"
    title = paper['title'].replace("{", "{{").replace("}", "}}")
    authors = " and ".join([f"{a['name']}" for a in paper['authors']])
    year = paper['submitted'][:4]
    month = paper['submitted'][5:7]
    months = {'01': 'jan', '02': 'feb', '03': 'mar', '04': 'apr', '05': 'may', '06': 'jun',
              '07': 'jul', '08': 'aug', '09': 'sep', '10': 'oct', '11': 'nov', '12': 'dec'}
    month_str = months.get(month, 'jan')
    
    return f"""@article{{{key},
  title={{{title}}},
  author={{{authors}}},
  journal={{arXiv preprint arXiv:{paper['id']}}},
  year={{{year}}},
  month={{{month_str}}},
}}"""

def save_papers_data():
    """Save sample papers to JSON files in papers directory."""
    for paper in SAMPLE_PAPERS:
        filepath = os.path.join(PAPERS_DIR, f"{paper['id']}.json")
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(paper, f, indent=2)

def load_all_papers():
    """Load all papers from the papers directory."""
    papers = []
    for file in os.listdir(PAPERS_DIR):
        if file.endswith(".json"):
            with open(os.path.join(PAPERS_DIR, file), 'r', encoding='utf-8') as f:
                papers.append(json.load(f))
    # Sort by submission date (newest first)
    papers.sort(key=lambda x: x['submitted'], reverse=True)
    return papers

def create_index_html(papers):
    """Create the main index page with navigation and paper list."""
    nav_items = "".join([
        f'<li><a href="category/{cat}.html">{cat} - {name}</a></li>'
        for cat, name in CS_CATEGORIES.items()
    ])
    
    paper_items = ""
    for paper in papers:
        submitted_time = datetime.fromisoformat(paper['submitted'].replace("Z", "+00:00")).strftime("%H:%M")
        categories_badge = " ".join([f"[{cat}]" for cat in paper['categories']])
        paper_items += f"""
        <div class="paper-item">
            <h3><a href="papers/{paper['id']}.html">{paper['title']}</a></h3>
            <p class="meta">Submitted: {submitted_time} | {categories_badge}</p>
        </div>
        """
    
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>arXiv CS Daily</title>
    <link rel="stylesheet" href="static/style.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>arXiv CS Daily</h1>
            <p>Latest Computer Science Preprints - Updated Daily</p>
        </header>

        <nav>
            <ul>
                <li><a href="index.html"><strong>All Papers</strong></a></li>
                {nav_items}
            </ul>
        </nav>

        <main>
            <h2>Today's Papers</h2>
            {paper_items}
        </main>

        <footer>
            <p>Data sourced from arXiv • Updated on {datetime.now().strftime('%Y-%m-%d')}</p>
        </footer>
    </div>
</body>
</html>"""
    
    with open(os.path.join(OUTPUT_DIR, "index.html"), "w", encoding='utf-8') as f:
        f.write(html)

def create_category_pages(papers):
    """Create individual category pages."""
    for category, name in CS_CATEGORIES.items():
        filtered_papers = [p for p in papers if category in p['categories']]
        
        if not filtered_papers:
            paper_items = "<p>No papers in this category today.</p>"
        else:
            paper_items = ""
            for paper in filtered_papers:
                submitted_time = datetime.fromisoformat(paper['submitted'].replace("Z", "+00:00")).strftime("%H:%M")
                categories_badge = " ".join([f"[{cat}]" for cat in paper['categories']])
                paper_items += f"""
                <div class="paper-item">
                    <h3><a href="../papers/{paper['id']}.html">{paper['title']}</a></h3>
                    <p class="meta">Submitted: {submitted_time} | {categories_badge}</p>
                </div>
                """
        
        html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{category} - arXiv CS Daily</title>
    <link rel="stylesheet" href="../static/style.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>arXiv CS Daily</h1>
            <p>{category} - {name}</p>
        </header>

        <nav>
            <ul>
                <li><a href="../index.html">All Papers</a></li>
                {''.join([f'<li><a href="../category/{cat}.html">{cat}</a></li>' for cat in CS_CATEGORIES])}
            </ul>
        </nav>

        <main>
            <h2>Papers in {category}</h2>
            {paper_items}
        </main>

        <footer>
            <p>Data sourced from arXiv • Updated on {datetime.now().strftime('%Y-%m-%d')}</p>
        </footer>
    </div>
</body>
</html>"""
        
        category_dir = os.path.join(OUTPUT_DIR, "category")
        os.makedirs(category_dir, exist_ok=True)
        with open(os.path.join(category_dir, f"{category}.html"), "w", encoding='utf-8') as f:
            f.write(html)

def create_paper_detail_pages(papers):
    """Create detailed page for each paper."""
    detail_dir = os.path.join(OUTPUT_DIR, "papers")
    os.makedirs(detail_dir, exist_ok=True)
    
    for paper in papers:
        authors_list = ", ".join([
            f"{a['name']}<br><small>{a['affiliation']}</small>" 
            for a in paper['authors']
        ])
        
        bibtex_citation = generate_bibtex(paper)
        standard_citation = f"""{'; '.join([a['name'] for a in paper['authors']])}. 
({paper['submitted'][:4]}). {paper['title']}. arXiv preprint arXiv:{paper['id']}."""
        
        categories_badge = " ".join([f"<span class='badge'>{cat}</span>" for cat in paper['categories']])
        
        html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{paper['title']} - arXiv CS Daily</title>
    <link rel="stylesheet" href="../static/style.css">
    <script>
        function copyCitation(format) {{
            let text = format === 'bibtex' ? `{bibtex_citation.replace('`', '\\`')}` : `{standard_citation.strip()}`
            navigator.clipboard.writeText(text).then(() => {{
                alert('Citation copied to clipboard!');
            }});
        }}
    </script>
</head>
<body>
    <div class="container">
        <header>
            <h1>arXiv CS Daily</h1>
            <p><a href="../index.html">← Back to all papers</a></p>
        </header>

        <main class="detail-page">
            <article>
                <h1>{paper['title']}</h1>
                
                <div class="paper-meta">
                    <div class="authors">
                        <h3>Authors</h3>
                        {authors_list}
                    </div>
                    
                    <div class="details">
                        <h3>Details</h3>
                        <p><strong>arXiv ID:</strong> {paper['id']}</p>
                        <p><strong>Submitted:</strong> {paper['submitted'].replace('T', ' ').replace('Z', ' UTC')}</p>
                        <p><strong>Categories:</strong> {categories_badge}</p>
                        {f'<p><strong>DOI:</strong> <a href="https://doi.org/{paper["doi"]}" target="_blank">{paper["doi"]}</a></p>' if paper["doi"] else ''}
                    </div>
                </div>

                <div class="content-links">
                    <h3>Resources</h3>
                    <p>
                        <a href="https://arxiv.org/pdf/{paper['id']}" class="btn" target="_blank">📄 View PDF</a>
                    </p>
                </div>

                <div class="citation">
                    <h3>Cite This Paper</h3>
                    <div class="citation-box">
                        <h4>BibTeX</h4>
                        <pre>{bibtex_citation}</pre>
                        <button onclick="copyCitation('bibtex')" class="copy-btn">📋 Copy BibTeX</button>
                    </div>
                    <div class="citation-box">
                        <h4>Standard Citation</h4>
                        <pre>{standard_citation}</pre>
                        <button onclick="copyCitation('standard')" class="copy-btn">📋 Copy Citation</button>
                    </div>
                </div>

                <div class="abstract">
                    <h3>Abstract</h3>
                    <p>{paper['abstract']}</p>
                </div>
            </article>
        </main>

        <footer>
            <p>Data sourced from arXiv • Updated on {datetime.now().strftime('%Y-%m-%d')}</p>
        </footer>
    </div>
</body>
</html>"""
        
        with open(os.path.join(detail_dir, f"{paper['id']}.html"), "w", encoding='utf-8') as f:
            f.write(html)

def create_static_files():
    """Create CSS stylesheet."""
    css = """* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    line-height: 1.6;
    color: #333;
    background-color: #f8f9fa;
}

.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
}

header {
    text-align: center;
    padding: 20px 0;
    margin-bottom: 30px;
    border-bottom: 1px solid #e9ecef;
}

header h1 {
    color: #0066cc;
    margin-bottom: 10px;
}

nav ul {
    display: flex;
    flex-wrap: wrap;
    list-style: none;
    background-color: #fff;
    padding: 10px;
    border-radius: 5px;
    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    justify-content: center;
    gap: 2px;
}

nav li {
    margin: 2px;
}

nav a {
    display: block;
    padding: 8px 12px;
    text-decoration: none;
    color: #0066cc;
    border-radius: 4px;
    font-size: 14px;
    transition: background-color 0.3s;
}

nav a:hover {
    background-color: #0066cc;
    color: white;
}

main {
    background-color: white;
    padding: 30px;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    margin-bottom: 30px;
}

h2 {
    color: #0066cc;
    margin-bottom: 20px;
    padding-bottom: 10px;
    border-bottom: 2px solid #eee;
}

.paper-item {
    margin-bottom: 25px;
    padding-bottom: 15px;
    border-bottom: 1px dashed #eee;
}

.paper-item:last-child {
    border-bottom: none;
}

.paper-item h3 {
    margin-bottom: 8px;
}

.paper-item h3 a {
    color: #0066cc;
    text-decoration: none;
}

.paper-item h3 a:hover {
    text-decoration: underline;
}

.meta {
    color: #666;
    font-size: 0.9em;
}

.badge {
    background-color: #e9ecef;
    color: #495057;
    padding: 2px 6px;
    border-radius: 4px;
    font-size: 0.8em;
    margin-right: 4px;
}

.btn, .copy-btn {
    background-color: #0066cc;
    color: white;
    border: none;
    padding: 10px 15px;
    border-radius: 5px;
    cursor: pointer;
    font-size: 14px;
    transition: background-color 0.3s;
    margin-top: 5px;
}

.btn:hover, .copy-btn:hover {
    background-color: #0055aa;
}

.copy-btn {
    font-size: 13px;
    padding: 6px 10px;
}

.detail-page .paper-meta {
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 30px;
    margin: 20px 0;
    padding: 20px;
    background-color: #f8f9fa;
    border-radius: 8px;
}

.detail-page .authors h3,
.detail-page .details h3 {
    margin-bottom: 15px;
    color: #0066cc;
}

.detail-page small {
    color: #666;
    font-style: italic;
}

.content-links {
    margin: 30px 0;
}

.citation {
    margin: 30px 0;
    padding: 20px;
    background-color: #f8f9fa;
    border-radius: 8px;
}

.citation h3 {
    margin-bottom: 15px;
    color: #0066cc;
}

.citation-box {
    margin-bottom: 20px;
}

.citation-box h4 {
    margin-bottom: 10px;
    color: #0066cc;
}

.citation-box pre {
    background-color: #fff;
    padding: 15px;
    border: 1px solid #ddd;
    border-radius: 5px;
    overflow-x: auto;
    margin-bottom: 10px;
    font-size: 14px;
    line-height: 1.4;
}

.abstract {
    margin: 30px 0;
    padding: 20px;
    background-color: #f8f9fa;
    border-radius: 8px;
}

.abstract h3 {
    margin-bottom: 15px;
    color: #0066cc;
}

footer {
    text-align: center;
    padding: 20px;
    color: #666;
    font-size: 0.9em;
    border-top: 1px solid #e9ecef;
    margin-top: 20px;
}

@media (max-width: 768px) {
    nav ul {
        flex-direction: column;
    }
    
    .detail-page .paper-meta {
        grid-template-columns: 1fr;
    }
    
    header, main, footer {
        padding: 15px;
    }
}"""
    
    static_dir = os.path.join(OUTPUT_DIR, "static")
    os.makedirs(static_dir, exist_ok=True)
    with open(os.path.join(static_dir, "style.css"), "w", encoding='utf-8') as f:
        f.write(css)

def main():
    """Main function to build the arXiv CS Daily website."""
    print("Saving sample paper data...")
    save_papers_data()
    
    print("Loading papers...")
    papers = load_all_papers()
    
    print("Creating static files...")
    create_static_files()
    
    print("Generating index page...")
    create_index_html(papers)
    
    print("Creating category pages...")
    create_category_pages(papers)
    
    print("Creating paper detail pages...")
    create_paper_detail_pages(papers)
    
    print(f"Website generated successfully in '{OUTPUT_DIR}' directory!")

if __name__ == "__main__":
    # Create papers directory if it doesn't exist
    os.makedirs("project/arxiv_cs_daily/papers", exist_ok=True)
    main()