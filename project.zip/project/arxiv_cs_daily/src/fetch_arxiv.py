import requests
from bs4 import BeautifulSoup
import feedparser
import json
from datetime import datetime
import re

def fetch_daily_papers(category: str = "cs", max_results: int = 100):
    """
    Fetch the latest papers from arXiv for a given category using arXiv API (via RSS feed).
    
    Args:
        category (str): arXiv category (e.g., 'cs', 'cs.AI', 'cs.CV')
        max_results (int): Maximum number of results to fetch
    
    Returns:
        list: List of parsed paper entries
    """
    base_url = "http://export.arxiv.org/api/query?"
    search_query = f"cat:{category}"
    params = {
        "search_query": search_query,
        "start": 0,
        "max_results": max_results,
        "sortBy": "submittedDate",
        "sortOrder": "descending"
    }
    
    response = requests.get(base_url, params=params)
    if response.status_code != 200:
        print(f"Error fetching data: {response.status_code}")
        return []
    
    feed = feedparser.parse(response.content)
    papers = [parse_paper_entry(entry) for entry in feed.entries]
    return [p for p in papers if p is not None]

def parse_paper_entry(entry):
    """
    Parse a single arXiv API entry into a structured dictionary.
    
    Args:
        entry: feedparser entry object
    
    Returns:
        dict: Parsed paper data or None if parsing fails
    """
    try:
        # Extract ID and clean it
        paper_id = entry.id.split('/abs/')[-1].split('v')[0]
        
        # Extract title and clean whitespace
        title = entry.title.replace('\n', ' ').strip()
        
        # Format authors with affiliations (arXiv API doesn't provide affiliations directly)
        authors = [author.name for author in entry.authors]
        
        # Extract summary and clean
        summary = BeautifulSoup(entry.summary, 'html.parser').get_text().strip()
        
        # Parse published date
        published = datetime(*entry.published_parsed[:6])
        published_str = published.strftime('%Y-%m-%d %H:%M:%S')
        
        # Get primary category
        category = entry.tags[0]['term'] if entry.tags else "cs"
        
        # Construct PDF link
        pdf_url = entry.id.replace('/abs/', '/pdf/') + ".pdf"
        
        return {
            "id": paper_id,
            "title": title,
            "authors": authors,
            "summary": summary,
            "published": published_str,
            "updated": getattr(entry, 'updated', published_str),
            "category": category,
            "url": entry.id,
            "pdf_url": pdf_url,
            "comment": getattr(entry, 'arxiv_comment', ''),
            "journal_ref": getattr(entry, 'arxiv_journal_ref', '')
        }
    except Exception as e:
        print(f"Error parsing entry: {e}")
        return None

def save_papers_to_file(papers, filename: str):
    """
    Save list of papers to a JSON file.
    
    Args:
        papers (list): List of paper dictionaries
        filename (str): Output filename
    """
    try:
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(papers, f, indent=2, ensure_ascii=False)
        print(f"Saved {len(papers)} papers to {filename}")
    except Exception as e:
        print(f"Error saving to file: {e}")

def load_papers_from_file(filename: str):
    """
    Load papers from a JSON file.
    
    Args:
        filename (str): Input filename
    
    Returns:
        list: List of paper dictionaries
    """
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            papers = json.load(f)
        print(f"Loaded {len(papers)} papers from {filename}")
        return papers
    except FileNotFoundError:
        print(f"File {filename} not found.")
        return []
    except Exception as e:
        print(f"Error loading file: {e}")
        return []

def get_paper_details(paper_id):
    """
    Retrieve detailed information for a specific paper by ID.
    Note: arXiv API has limitations; this function can be extended with web scraping if needed.
    
    Args:
        paper_id (str): arXiv paper ID (e.g., '2401.12345')
    
    Returns:
        dict: Paper details or None
    """
    # For now, we'll use the same API - in future could add HTML scraping for more metadata
    base_url = f"http://export.arxiv.org/api/query?id_list={paper_id}"
    response = requests.get(base_url)
    
    if response.status_code != 200:
        return None
        
    feed = feedparser.parse(response.content)
    if not feed.entries:
        return None
        
    return parse_paper_entry(feed.entries[0])

def generate_citation_bibtex(paper):
    """
    Generate BibTeX citation for a paper.
    
    Args:
        paper (dict): Paper data dictionary
    
    Returns:
        str: BibTeX formatted citation
    """
    try:
        # Create citation key: first author last name + year + first word of title
        first_author = paper['authors'][0].split(' ')[-1]
        year = paper['published'][:4]
        first_word = re.sub(r'[^a-zA-Z]', '', paper['title'].split()[0].lower())
        citation_key = f"{first_author}{year}{first_word}"
        
        # Clean title for BibTeX
        title = paper['title'].replace('{', '\\{').replace('}', '\\}')
        
        # Format authors
        authors = " and ".join([author.replace(',', ', ') for author in paper['authors']])
        
        # Create BibTeX entry
        bibtex = f"""@article{{{citation_key},
  title={{{title}}},
  author={{{authors}}},
  journal={{arXiv preprint arXiv:{paper['id']}}},
  year={{{year}}},
  url={{{paper['url']}}},
}}"""
        
        return bibtex
    except Exception as e:
        print(f"Error generating BibTeX: {e}")
        return ""

def main():
    """
    Main function to demonstrate functionality.
    Fetches papers, saves to file, loads from file, and generates citation.
    """
    # Fetch papers from computer science category
    print("Fetching latest CS papers...")
    papers = fetch_daily_papers("cs", max_results=50)
    
    if papers:
        # Save to file
        timestamp = datetime.now().strftime("%Y%m%d")
        filename = f"arxiv_cs_{timestamp}.json"
        save_papers_to_file(papers, filename)
        
        # Load from file (demonstration)
        loaded_papers = load_papers_from_file(filename)
        
        # Generate citation for first paper
        if loaded_papers:
            print("\nFirst paper:")
            print(f"Title: {loaded_papers[0]['title']}")
            print(f"Authors: {', '.join(loaded_papers[0]['authors'])}")
            print(f"Published: {loaded_papers[0]['published']}")
            print(f"Category: {loaded_papers[0]['category']}")
            
            bibtex = generate_citation_bibtex(loaded_papers[0])
            print(f"\nBibTeX Citation:\n{bibtex}")

if __name__ == "__main__":
    main()